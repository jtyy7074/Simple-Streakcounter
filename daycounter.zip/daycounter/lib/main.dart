import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import 'package:home_widget/home_widget.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await HomeWidget.setAppGroupId('com.daycounter.app');
  runApp(const DayCounterApp());
}

class Counter {
  final String id;
  String title;
  DateTime startDate;
  bool showOnLockScreen;

  Counter({
    required this.id,
    required this.title,
    required this.startDate,
    this.showOnLockScreen = false,
  });

  int get dayCount {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final start = DateTime(startDate.year, startDate.month, startDate.day);
    return today.difference(start).inDays;
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'startDate': startDate.toIso8601String(),
    'showOnLockScreen': showOnLockScreen,
  };

  factory Counter.fromJson(Map<String, dynamic> json) => Counter(
    id: json['id'],
    title: json['title'],
    startDate: DateTime.parse(json['startDate']),
    showOnLockScreen: json['showOnLockScreen'] ?? false,
  );
}

class DayCounterApp extends StatelessWidget {
  const DayCounterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Day Counter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF5C6BC0),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF5C6BC0),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const CounterListPage(),
    );
  }
}

class CounterListPage extends StatefulWidget {
  const CounterListPage({super.key});

  @override
  State<CounterListPage> createState() => _CounterListPageState();
}

class _CounterListPageState extends State<CounterListPage> {
  List<Counter> _counters = [];
  final _uuid = const Uuid();

  @override
  void initState() {
    super.initState();
    _loadCounters();
  }

  Future<void> _loadCounters() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('counters');
    if (data != null) {
      final List decoded = jsonDecode(data);
      setState(() {
        _counters = decoded.map((e) => Counter.fromJson(e)).toList();
      });
    }
  }

  Future<void> _saveCounters() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'counters',
      jsonEncode(_counters.map((c) => c.toJson()).toList()),
    );
    await _updateWidget();
  }

  Future<void> _updateWidget() async {
    final lockCounter = _counters.where((c) => c.showOnLockScreen).firstOrNull;
    if (lockCounter != null) {
      await HomeWidget.saveWidgetData<String>('widget_title', lockCounter.title);
      await HomeWidget.saveWidgetData<int>('widget_days', lockCounter.dayCount);
    } else {
      await HomeWidget.saveWidgetData<String>('widget_title', '');
      await HomeWidget.saveWidgetData<int>('widget_days', 0);
    }
    await HomeWidget.updateWidget(
      androidName: 'DayCounterWidget',
      iOSName: 'DayCounterWidget',
    );
  }

  void _setLockScreen(Counter selected) {
    setState(() {
      for (var c in _counters) {
        c.showOnLockScreen = (c.id == selected.id) ? !c.showOnLockScreen : false;
      }
      // If we just turned it on, make sure only this one is on
      if (selected.showOnLockScreen == false) {
        // it was turned off already via toggle above — do nothing extra
      }
    });
    _saveCounters();
  }

  void _showAddEditDialog({Counter? existing}) {
    final titleController = TextEditingController(text: existing?.title ?? '');
    DateTime selectedDate = existing?.startDate ?? DateTime.now();

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setDialogState) {
          return AlertDialog(
            title: Text(existing == null ? 'New Counter' : 'Edit Counter'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    labelText: 'Title',
                    border: OutlineInputBorder(),
                  ),
                  textCapitalization: TextCapitalization.sentences,
                ),
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  icon: const Icon(Icons.calendar_today),
                  label: Text(DateFormat('d MMM yyyy').format(selectedDate)),
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: selectedDate,
                      firstDate: DateTime(2000),
                      lastDate: DateTime.now(),
                    );
                    if (picked != null) {
                      setDialogState(() => selectedDate = picked);
                    }
                  },
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () {
                  final title = titleController.text.trim();
                  if (title.isEmpty) return;
                  setState(() {
                    if (existing == null) {
                      _counters.add(Counter(
                        id: _uuid.v4(),
                        title: title,
                        startDate: selectedDate,
                      ));
                    } else {
                      existing.title = title;
                      existing.startDate = selectedDate;
                    }
                  });
                  _saveCounters();
                  Navigator.pop(context);
                },
                child: const Text('Save'),
              ),
            ],
          );
        });
      },
    );
  }

  void _deleteCounter(Counter counter) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Counter'),
        content: Text('Delete "${counter.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            onPressed: () {
              setState(() => _counters.remove(counter));
              _saveCounters();
              Navigator.pop(context);
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: scheme.surface,
      appBar: AppBar(
        backgroundColor: scheme.primary,
        foregroundColor: scheme.onPrimary,
        title: const Text('Day Counter', style: TextStyle(fontWeight: FontWeight.bold)),
        elevation: 0,
      ),
      body: _counters.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.calendar_month, size: 64, color: scheme.primary.withOpacity(0.4)),
                  const SizedBox(height: 16),
                  Text(
                    'No counters yet',
                    style: TextStyle(
                      fontSize: 18,
                      color: scheme.onSurface.withOpacity(0.5),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Tap + to add your first counter',
                    style: TextStyle(color: scheme.onSurface.withOpacity(0.4)),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _counters.length,
              itemBuilder: (context, index) {
                final counter = _counters[index];
                return _CounterCard(
                  counter: counter,
                  onLockScreenToggle: () => _setLockScreen(counter),
                  onEdit: () => _showAddEditDialog(existing: counter),
                  onDelete: () => _deleteCounter(counter),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditDialog(),
        icon: const Icon(Icons.add),
        label: const Text('Add Counter'),
      ),
    );
  }
}

class _CounterCard extends StatelessWidget {
  final Counter counter;
  final VoidCallback onLockScreenToggle;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _CounterCard({
    required this.counter,
    required this.onLockScreenToggle,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final days = counter.dayCount;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    counter.title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                PopupMenuButton(
                  itemBuilder: (context) => [
                    const PopupMenuItem(value: 'edit', child: Row(children: [Icon(Icons.edit, size: 18), SizedBox(width: 8), Text('Edit')])),
                    const PopupMenuItem(value: 'delete', child: Row(children: [Icon(Icons.delete, size: 18, color: Colors.red), SizedBox(width: 8), Text('Delete', style: TextStyle(color: Colors.red))])),
                  ],
                  onSelected: (v) {
                    if (v == 'edit') onEdit();
                    if (v == 'delete') onDelete();
                  },
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '$days',
                  style: TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.w800,
                    color: scheme.primary,
                    height: 1,
                  ),
                ),
                const SizedBox(width: 8),
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    days == 1 ? 'day' : 'days',
                    style: TextStyle(
                      fontSize: 18,
                      color: scheme.onSurface.withOpacity(0.6),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'Since ${DateFormat('d MMM yyyy').format(counter.startDate)}',
              style: TextStyle(
                fontSize: 13,
                color: scheme.onSurface.withOpacity(0.5),
              ),
            ),
            const Divider(height: 24),
            Row(
              children: [
                Icon(
                  Icons.lock_outline,
                  size: 18,
                  color: counter.showOnLockScreen ? scheme.primary : scheme.onSurface.withOpacity(0.4),
                ),
                const SizedBox(width: 8),
                Text(
                  'Show on lock screen',
                  style: TextStyle(
                    color: counter.showOnLockScreen ? scheme.primary : scheme.onSurface.withOpacity(0.6),
                    fontWeight: counter.showOnLockScreen ? FontWeight.w600 : FontWeight.normal,
                  ),
                ),
                const Spacer(),
                Switch(
                  value: counter.showOnLockScreen,
                  onChanged: (_) => onLockScreenToggle(),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
