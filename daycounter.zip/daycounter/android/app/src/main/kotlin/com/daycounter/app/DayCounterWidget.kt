package com.daycounter.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetPlugin

class DayCounterWidget : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            val widgetData = HomeWidgetPlugin.getData(context)
            val title = widgetData.getString("widget_title", "Day Counter") ?: "Day Counter"
            val days = widgetData.getInt("widget_days", 0)

            val views = RemoteViews(context.packageName, R.layout.day_counter_widget).apply {
                setTextViewText(R.id.widget_title, title)
                setTextViewText(R.id.widget_days, days.toString())
            }

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
