package com.daycounter.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
